﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MicrobiologiaDTOs;
using MicrobiologiaManager;
using Microsoft.AspNetCore.Mvc;

namespace MicrobiologiaTest.Controllers
{
    [Route("api/[controller]")]
    public class ValuesController : Controller
    {
        public IInfoManager infoManager = new InfoManager();
        public IJuegoManager juegoManager = new JuegoManager();

        [HttpGet]
        public String GetDefault()
        {
            return "Bienvenido a la WebAPI de Microbiologia Test";
        }
       
        [HttpGet("getJuego", Name ="GetJuego")]
        public List<Pregunta> GetJuego()
        {
            return juegoManager.GetAllForJuego();
        }

        [HttpGet("getRecursos", Name = "GetRecursos")]
        public List<RecursosInfo> GetRecursos()
        {
            return infoManager.getRecursos();
        }

        [HttpGet("getIgNobels", Name = "GetIgNobels")]
        public List<IgNobelInfo> GetIgNobels()
        {
            return infoManager.getIgNobels();
        }
    }
}
