﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MicrobiologiaDTOs
{
    public class IgNobelInfo
    {
        public int IgNobelID { get; set; }
        public string Categoria { get; set; }
        public string Descripcion { get; set; }
        public string Anio { get; set; }
    }
}
