﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MicrobiologiaDTOs
{
    public class Pregunta
    {
        public int PreguntaId { get; set; }
        public string Texto { get; set; }
        public bool RespuestaCorrecta { get; set; }
        public string Dificultad { get; set; }
        public string GruposMicros { get; set; }
    }
}
