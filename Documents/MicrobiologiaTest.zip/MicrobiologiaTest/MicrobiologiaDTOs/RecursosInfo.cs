﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MicrobiologiaDTOs
{
    public class RecursosInfo
    {
        public int RecursoID { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Categoria { get; set; }
    }
}
