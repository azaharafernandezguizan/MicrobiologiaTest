﻿using System;
using System.Collections.Generic;

namespace MicrobiologiaDBContext.Models
{
    public partial class Ignobel
    {
        public string Anio { get; set; }
        public string Descripcion { get; set; }
        public string Categoria { get; set; }
        public int Id { get; set; }
    }
}
