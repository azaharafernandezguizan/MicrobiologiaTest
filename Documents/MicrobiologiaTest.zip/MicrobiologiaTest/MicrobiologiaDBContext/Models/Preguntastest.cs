﻿using System;
using System.Collections.Generic;

namespace MicrobiologiaDBContext.Models
{
    public partial class Preguntastest
    {
        public string Pregunta { get; set; }
        public string RespuestaCorrecta { get; set; }
        public string Dificultad { get; set; }
        public string GrupoMicros { get; set; }
        public int Id { get; set; }
    }
}
