﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Configuration;

namespace MicrobiologiaDBContext.Models
{
    public partial class microbiologiatestContext : DbContext
    {
        public microbiologiatestContext()
        {
        }

        public microbiologiatestContext(DbContextOptions<microbiologiatestContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Ignobel> Ignobel { get; set; }
        public virtual DbSet<Preguntastest> Preguntastest { get; set; }
        public virtual DbSet<Recursos> Recursos { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                IConfigurationRoot configuration = new ConfigurationBuilder()
                    .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                    .AddJsonFile("appsettings.json")
                    .Build();

                optionsBuilder.UseMySql(configuration.GetConnectionString("MicrobiologiaDatabase"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Ignobel>(entity =>
            {
                entity.ToTable("ignobel");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Anio)
                    .HasColumnName("anio")
                    .HasColumnType("text");

                entity.Property(e => e.Categoria)
                    .HasColumnName("categoria")
                    .HasColumnType("text");

                entity.Property(e => e.Descripcion)
                    .HasColumnName("descripcion")
                    .HasColumnType("text");
            });

            modelBuilder.Entity<Preguntastest>(entity =>
            {
                entity.ToTable("preguntastest");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Dificultad)
                    .HasColumnName("dificultad")
                    .HasColumnType("text");

                entity.Property(e => e.GrupoMicros)
                    .HasColumnName("grupo_micros")
                    .HasColumnType("text");

                entity.Property(e => e.Pregunta)
                    .HasColumnName("pregunta")
                    .HasColumnType("text");

                entity.Property(e => e.RespuestaCorrecta)
                    .HasColumnName("respuesta_correcta")
                    .HasColumnType("text");
            });

            modelBuilder.Entity<Recursos>(entity =>
            {
                entity.ToTable("recursos");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Categoria)
                    .HasColumnName("categoria")
                    .HasColumnType("text");

                entity.Property(e => e.Descripcion)
                    .HasColumnName("descripcion")
                    .HasColumnType("text");

                entity.Property(e => e.Titulo)
                    .HasColumnName("titulo")
                    .HasColumnType("text");
            });
        }
    }
}
