﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MicrobiologiaDBContext.Models;
using Microsoft.EntityFrameworkCore;

namespace MicrobiologiaBusinessLogic
{
    public class IgnobelRepository : IIgnobelRepository, IDisposable
    {
        private microbiologiatestContext context;

        public IgnobelRepository(microbiologiatestContext context)
        {
            this.context = context;
        }

        public void DeleteIgNobel(int ignobelID)
        {
            Ignobel igNobel = context.Ignobel.Find(ignobelID);
            context.Ignobel.Remove(igNobel);
        }
        

        public List<Ignobel> GetAllIgNobels()
        {
            return context.Ignobel.ToList();
        }

        public Ignobel GetIgNobelById(int ignobelID)
        {
            return context.Ignobel.Find(ignobelID);
        }

        public void InsertIgNobel(Ignobel ignobel)
        {
            context.Ignobel.Add(ignobel);
        }

        public void UpdateIgNobel(Ignobel ignobel)
        {
            context.Entry(ignobel).State = EntityState.Modified;
        }

        #region IDisposable Support
        private bool disposedValue = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    context.Dispose();
                }

                disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}
