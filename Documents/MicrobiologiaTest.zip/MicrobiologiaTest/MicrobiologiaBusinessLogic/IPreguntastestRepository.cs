﻿using MicrobiologiaDBContext.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MicrobiologiaBusinessLogic
{
    public interface IPreguntastestRepository: IDisposable
    {
        void InsertPregunta(Preguntastest pregunta);
        void DeletePregunta(int preguntaID);
        void UpdatePregunta(Preguntastest pregunta);
        List<Preguntastest> GetAllPreguntas();
        Preguntastest GetPreguntaById(int preguntaID);
    }
}
