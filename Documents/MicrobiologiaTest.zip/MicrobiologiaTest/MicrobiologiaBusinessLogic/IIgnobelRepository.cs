﻿using MicrobiologiaDBContext.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MicrobiologiaBusinessLogic
{
    public interface IIgnobelRepository: IDisposable
    {
        void InsertIgNobel(Ignobel ignobel);
        void DeleteIgNobel(int ignobelID);
        void UpdateIgNobel(Ignobel ignobel);
        List<Ignobel> GetAllIgNobels();
        Ignobel GetIgNobelById(int ignobelID);
    }
}
