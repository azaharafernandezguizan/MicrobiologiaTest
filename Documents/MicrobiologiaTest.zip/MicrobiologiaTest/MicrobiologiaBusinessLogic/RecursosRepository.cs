﻿using System;
using System.Collections.Generic;
using System.Linq;
using MicrobiologiaDBContext.Models;
using Microsoft.EntityFrameworkCore;

namespace MicrobiologiaBusinessLogic
{
    public class RecursosRepository : IRecursosRepository, IDisposable
    {
        private microbiologiatestContext context;

        public RecursosRepository(microbiologiatestContext context)
        {
            this.context = context;
        }
        public void DeleteRecurso(int recursoID)
        {
            Recursos recurso = context.Recursos.Find(recursoID);
            context.Recursos.Remove(recurso);
        }
        

        public List<Recursos> GetAllRecursos()
        {
            return context.Recursos.ToList();
        }

        public Recursos GetRecursoById(int recursoID)
        {
            return context.Recursos.Find(recursoID);
        }

        public void InsertRecurso(Recursos recurso)
        {
            context.Recursos.Add(recurso);
        }

        public void UpdateRecurso(Recursos recurso)
        {
            context.Entry(recurso).State = EntityState.Modified;
        }

        #region IDisposable Support
        private bool disposedValue = false; 

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    context.Dispose();
                }

                disposedValue = true;
            }
        }
        
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}
