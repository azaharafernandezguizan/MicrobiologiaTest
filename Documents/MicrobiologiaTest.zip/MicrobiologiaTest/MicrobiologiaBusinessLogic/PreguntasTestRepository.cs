﻿using MicrobiologiaDBContext.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MicrobiologiaBusinessLogic
{
    public class PreguntastestRepository: IPreguntastestRepository, IDisposable
    {
        private microbiologiatestContext context;
        
        public PreguntastestRepository(microbiologiatestContext context)
        {
            this.context = context;
        }

        public void InsertPregunta(Preguntastest pregunta)
        {
            context.Preguntastest.Add(pregunta);
        }

        public void DeletePregunta(int preguntaID)
        {
            Preguntastest pregunta = context.Preguntastest.Find(preguntaID);
            context.Preguntastest.Remove(pregunta);
        }

        public void UpdatePregunta(Preguntastest pregunta)
        {
            context.Entry(pregunta).State = EntityState.Modified;
        }

        public List<Preguntastest> GetAllPreguntas()
        {
            return context.Preguntastest.ToList();
        }

        public Preguntastest GetPreguntaById(int preguntaID)
        {
            return context.Preguntastest.Find(preguntaID);
        }





        #region IDisposable Support
        private bool disposedValue = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    context.Dispose();
                }

                disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}
