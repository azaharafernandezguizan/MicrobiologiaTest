﻿using MicrobiologiaDBContext.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MicrobiologiaBusinessLogic
{
    public interface IRecursosRepository: IDisposable
    {
        void InsertRecurso(Recursos recurso);
        void DeleteRecurso(int recursoID);
        void UpdateRecurso(Recursos recurso);
        List<Recursos> GetAllRecursos();
        Recursos GetRecursoById(int recursoID);
    }
}
