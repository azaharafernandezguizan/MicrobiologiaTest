﻿using MicrobiologiaDBContext.Models;
using MicrobiologiaDTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace MicrobiologiaManager
{
    public interface IInfoManager
    {
        List<RecursosInfo> getRecursos();
        List<IgNobelInfo> getIgNobels();
    }
}
