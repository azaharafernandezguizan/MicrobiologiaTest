﻿using MicrobiologiaDTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace MicrobiologiaManager
{
    public interface IJuegoManager
    {
        List<Pregunta> GetAllForJuego();
    }
}
