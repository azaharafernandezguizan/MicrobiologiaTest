﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MicrobiologiaBusinessLogic;
using MicrobiologiaDBContext.Models;
using MicrobiologiaDTOs;

namespace MicrobiologiaManager
{
    public class InfoManager : IInfoManager
    {
        public IIgnobelRepository ignobelRepository = new IgnobelRepository(new microbiologiatestContext());
        private IRecursosRepository recursosRepository = new RecursosRepository(new microbiologiatestContext());

        public List<IgNobelInfo> getIgNobels()
        {
            List<Ignobel> objectList = ignobelRepository.GetAllIgNobels();
             return objectList.Select(x => new IgNobelInfo
                        {
                           IgNobelID = x.Id,
                           Anio = x.Anio,
                           Categoria = x.Categoria,
                           Descripcion = x.Descripcion
                        }).ToList();
        }

        public List<RecursosInfo> getRecursos()
        {
            List<Recursos> objectList = recursosRepository.GetAllRecursos();
            return objectList.Select(x => new RecursosInfo
            {
                RecursoID = x.Id,
                Nombre = x.Titulo,
                Descripcion = x.Descripcion,
                Categoria = x.Categoria
            }).ToList();
        }
    }
}
