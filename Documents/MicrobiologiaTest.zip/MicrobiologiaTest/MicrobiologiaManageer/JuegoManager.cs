﻿using MicrobiologiaBusinessLogic;
using MicrobiologiaDBContext.Models;
using MicrobiologiaDTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MicrobiologiaManager
{
    public class JuegoManager: IJuegoManager
    {
        public IPreguntastestRepository preguntasRepository = new PreguntastestRepository(new microbiologiatestContext());

        public List<Pregunta> GetAllForJuego()
        {
            List<Preguntastest> objectList = preguntasRepository.GetAllPreguntas();
            return objectList.Select(x => new Pregunta
            {
                PreguntaId = x.Id,
                GruposMicros = x.GrupoMicros,
                Dificultad = x.Dificultad,
                RespuestaCorrecta = x.RespuestaCorrecta =="true",
                Texto = x.Pregunta
            }).ToList();
        }
    }
}
